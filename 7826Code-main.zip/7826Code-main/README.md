# 7826Code
Timed robot code for FRC team 7826. Many thanks to [manfart2021](https://github.com/manfart2021) for helping us make swerve drive possible.

## Driving

## Shooting

## Auton

# Contributors
- [manfart2021](https://github.com/manfart2021)
- [PangolinPope](https://github.com/PangolinPope)
- [SuperBoyne](https://github.com/SuperBoyne)
